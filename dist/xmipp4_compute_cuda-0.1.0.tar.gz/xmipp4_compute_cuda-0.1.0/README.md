# xmipp4-compute-cuda
CUDA compute backend for xmipp4

## SonarCloud status
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=gigabit-clowns_xmipp4-compute-cuda&metric=alert_status)](https://sonarcloud.io/summary/new_code?id=gigabit-clowns_xmipp4-compute-cuda)

### Ratings
[![Maintainability Rating](https://sonarcloud.io/api/project_badges/measure?project=gigabit-clowns_xmipp4-compute-cuda&metric=sqale_rating)](https://sonarcloud.io/summary/new_code?id=gigabit-clowns_xmipp4-compute-cuda)
[![Reliability Rating](https://sonarcloud.io/api/project_badges/measure?project=gigabit-clowns_xmipp4-compute-cuda&metric=reliability_rating)](https://sonarcloud.io/summary/new_code?id=gigabit-clowns_xmipp4-compute-cuda)
[![Security Rating](https://sonarcloud.io/api/project_badges/measure?project=gigabit-clowns_xmipp4-compute-cuda&metric=security_rating)](https://sonarcloud.io/summary/new_code?id=gigabit-clowns_xmipp4-compute-cuda)
[![Technical Debt](https://sonarcloud.io/api/project_badges/measure?project=gigabit-clowns_xmipp4-compute-cuda&metric=sqale_index)](https://sonarcloud.io/summary/new_code?id=gigabit-clowns_xmipp4-compute-cuda)

### Specific metrics
[![Bugs](https://sonarcloud.io/api/project_badges/measure?project=gigabit-clowns_xmipp4-compute-cuda&metric=bugs)](https://sonarcloud.io/summary/new_code?id=gigabit-clowns_xmipp4-compute-cuda)
[![Code Smells](https://sonarcloud.io/api/project_badges/measure?project=gigabit-clowns_xmipp4-compute-cuda&metric=code_smells)](https://sonarcloud.io/summary/new_code?id=gigabit-clowns_xmipp4-compute-cuda)
[![Vulnerabilities](https://sonarcloud.io/api/project_badges/measure?project=gigabit-clowns_xmipp4-compute-cuda&metric=vulnerabilities)](https://sonarcloud.io/summary/new_code?id=gigabit-clowns_xmipp4-compute-cuda)
[![Duplicated Lines (%)](https://sonarcloud.io/api/project_badges/measure?project=gigabit-clowns_xmipp4-compute-cuda&metric=duplicated_lines_density)](https://sonarcloud.io/summary/new_code?id=gigabit-clowns_xmipp4-compute-cuda)
[![Lines of Code](https://sonarcloud.io/api/project_badges/measure?project=gigabit-clowns_xmipp4-compute-cuda&metric=ncloc)](https://sonarcloud.io/summary/new_code?id=gigabit-clowns_xmipp4-compute-cuda)
